# Individual Project 3: API Introduction and Setup an API Server with MySQL and Express

## Project Summary

##### This project shows how to setup nodejs with mysql docker 

#### Browser
![Index Route](screenshots/browser.png)

#### Webstorm
![create route](screenshots/webstorm.png)

