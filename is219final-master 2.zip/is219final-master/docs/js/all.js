(function ($) {
   let table =  $('#citiesTable').DataTable( {
        "ajax": "http://localhost:9080/api/v1/cities",
        "columns": [
            {"data":"Index"},
            {"data":"Sell"},
            { "data": "List"},
            { "data": "Living" },
            { "data": "Rooms" },
            { "data": "Beds" },
            { "data": "Baths" },
            { "data": "Age" },
            { "data": "Acres" },
            { "data": "Taxes" }
        ]
    } );
})(jQuery);